const CustomIconWithTextData1 = [
    {
        img: "https://via.placeholder.com/75x66",
        title: "SIGNIFICANT BAR",
        content: "Lorem ipsum dolor sit amet sectetura dipisicing"
    },
    {
        img: "https://via.placeholder.com/75x66",
        title: "WONDERFUL CUISINE",
        content: "Lorem ipsum dolor sit amet sectetura dipisicing"
    },
    {
        img: "https://via.placeholder.com/75x66",
        title: "CLASSIC RESTAURANT",
        content: "Lorem ipsum dolor sit amet sectetura dipisicing"
    },
    {
        img: "https://via.placeholder.com/75x66",
        title: "BEST MASTERCHEFS",
        content: "Lorem ipsum dolor sit amet sectetura dipisicing"
    },
]

const CustomIconWithTextData2 = [

    {
        icon: "line-icon-Navigation-LeftWindow",
        title: "Amazing layouts",
        content: "Lorem ipsum is simply dummy text of the printing typesetting lorem ipsum been text."
    },
    {
        icon: "line-icon-Cursor-Click2",
        title: "No coding required",
        content: "Lorem ipsum is simply dummy text of the printing typesetting lorem ipsum been text."
    },
    {
        icon: "line-icon-Like-2",
        title: "Easy to customize",
        content: "Lorem ipsum is simply dummy text of the printing typesetting lorem ipsum been text."
    },
    {
        icon: "line-icon-Talk-Man",
        title: "Customer satisfaction",
        content: "Lorem ipsum is simply dummy text of the printing typesetting lorem ipsum been text."
    },
    {
        icon: "line-icon-Paper-Plane",
        title: "Blazing performance",
        content: "Lorem ipsum is simply dummy text of the printing typesetting lorem ipsum been text."
    },
    {
        icon: "line-icon-Heart",
        title: "Huge icon collection",
        content: "Lorem ipsum is simply dummy text of the printing typesetting lorem ipsum been text."
    }

]

export { CustomIconWithTextData1, CustomIconWithTextData2 }