const OverLineData = [
    {
        title: "Personal integrity ",
        content: "Lorem ipsum dolor amet consectetur adipiscing elit do eiusmod incididunt ut labore et dolore magna.",
        icon: "line-icon-Business-Man"
    },
    {
        title: "Strengthen your skills",
        content: "Lorem ipsum dolor amet consectetur adipiscing elit do eiusmod incididunt ut labore et dolore magna.",
        icon: "line-icon-Air-Balloon"
    },
    {
        title: "Make ideas happen",
        content: "Lorem ipsum dolor amet consectetur adipiscing elit do eiusmod incididunt ut labore et dolore magna.",
        icon: "line-icon-Idea-5"
    }
]
export  {OverLineData}