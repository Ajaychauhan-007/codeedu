const RotateBoxData = [
    {
        img: "https://via.placeholder.com/720x828",
        title: "Ayurvedic",
        subtitle: "Starting from $50",
        icon: "line-icon-Environmental-3",
        btnLink: "#",
        btnTitle: "Discover more",
        content: "Lorem ipsum dolor sit amet consectetur do eiusmod tempor incididunt labore ut enim"
    },
    {
        img: "https://via.placeholder.com/720x828",
        title: "Fairness",
        subtitle: "Starting from $90",
        icon: "line-icon-Crown",
        btnLink: "#",
        btnTitle: "Discover more",
        content: "Lorem ipsum dolor sit amet consectetur do eiusmod tempor incididunt labore ut enim"
    },
    {
        img: "https://via.placeholder.com/720x828",
        title: "Herbal",
        subtitle: "Starting from $75",
        icon: "line-icon-Daylight",
        btnLink: "#",
        btnTitle: "Discover more",
        content: "Lorem ipsum dolor sit amet consectetur do eiusmod tempor incididunt labore ut enim"
    }
]

export default RotateBoxData;